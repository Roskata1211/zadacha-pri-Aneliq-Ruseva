﻿using System.ComponentModel.DataAnnotations;

namespace ToDoApp.Data
{
    public class ToDoItem
    {
        [Key]
        public int Id { get; set; }
        public string AssigneeId { get; set; }
        public virtual AppUser? Assignee { get; set; }
        public string Title { get; set; }
        public DateTime DeadLine { get; set; }
        public string Description { get; set; }
        public virtual ToDoList? ToDoList { get; set; }
    }
}